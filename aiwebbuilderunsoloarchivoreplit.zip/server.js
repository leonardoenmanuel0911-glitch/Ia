// AI WEB BUILDER - PROYECTO COMPLETO EN UN SOLO ARCHIVO
// Replit: crea proyecto Node.js, pega esto en server.js,
// configura Secrets y pulsa Run. No requiere npm install.

const http = require("http");
const fs = require("fs");
const crypto = require("crypto");

const PORT = process.env.PORT || 3000;
const ADMIN_KEY = process.env.ADMIN_KEY || "azteca0911";
const INITIAL_CREDITS = Number(process.env.INITIAL_CREDITS || 5);
const DB_FILE = "database.json";

let db = { users: [], devices: [], generations: [] };
if (fs.existsSync(DB_FILE)) {
  try { db = JSON.parse(fs.readFileSync(DB_FILE, "utf8")); } catch (e) {}
}

function saveDb() { fs.writeFileSync(DB_FILE, JSON.stringify(db, null, 2)); }

function findUserByUsername(username) {
  return db.users.find(u => u.username.toLowerCase() === String(username).toLowerCase());
}

function findUserByToken(token) {
  const device = db.devices.find(d => d.token === token);
  if (!device) return null;
  return db.users.find(u => u.id === device.userId) || null;
}

function parseCookies(req) {
  const cookies = {};
  (req.headers.cookie || "").split(";").forEach(part => {
    const [key, ...value] = part.trim().split("=");
    if (key) cookies[key] = decodeURIComponent(value.join("="));
  });
  return cookies;
}

function sendJson(res, status, data) {
  res.writeHead(status, { "Content-Type": "application/json; charset=utf-8", "Cache-Control": "no-store" });
  res.end(JSON.stringify(data));
}

function readBody(req) {
  return new Promise(resolve => {
    let body = "";
    req.on("data", c => body += c);
    req.on("end", () => { try { resolve(JSON.parse(body || "{}")); } catch { resolve({}); } });
  });
}

async function generateWithAI(prompt) {
  const models = [
    process.env.AI_MODEL_1 || "openrouter/free",
    process.env.AI_MODEL_2 || "nvidia/nemotron-3-ultra-550b-a55b:free",
    process.env.AI_MODEL_3 || "google/gemma-4-31b-it:free"
  ].filter(Boolean);

  const systemPrompt = `
Eres un agente de IA experto en crear sitios web y aplicaciones web completas, similar a Manus AI.
Recibes una instruccion en lenguaje natural y entregas un producto terminado.
Analiza el objetivo, publico, contenido y funcionalidad.
Decide automaticamente diseno, estructura, colores, tipografia, secciones y navegacion.
Crea un archivo HTML completo, moderno, responsive y funcional.
Incluye CSS y JavaScript dentro del mismo HTML.
Adaptate a cualquier proyecto: tienda, blog, portafolio, restaurante, agencia, escuela, evento o app.
Incluye secciones utiles: menus, formularios, galerias, precios, testimonios, FAQ y contacto.
Escribe textos realistas y profesionales en espanol.
No expliques nada ni uses markdown.
Devuelve unicamente el codigo, comenzando exactamente con <!DOCTYPE html>.
`;

  let lastError = "";

  for (const model of models) {
    try {
      const response = await fetch("https://openrouter.ai/api/v1/chat/completions", {
        method: "POST",
        headers: {
          Authorization: `Bearer ${process.env.OPENROUTER_API_KEY}`,
          "Content-Type": "application/json",
          "HTTP-Referer": "https://replit.com",
          "X-Title": "AI Web Builder"
        },
        body: JSON.stringify({
          model,
          messages: [
            { role: "system", content: systemPrompt },
            { role: "user", content: prompt }
          ],
          max_tokens: 8000,
          temperature: 0.7
        })
      });

      if (!response.ok) { lastError = `Modelo ${model}: ${response.status}`; continue; }

      const data = await response.json();
      const content = data.choices?.[0]?.message?.content || "";

      if (content.toLowerCase().includes("<!doctype html")) {
        return { html: content, model };
      }

      lastError = `Modelo ${model}: respuesta invalida`;
    } catch (error) {
      lastError = `Modelo ${model}: ${error.message}`;
    }
  }

  throw new Error(lastError || "Ninguna IA gratuita respondio");
}

const HTML = `<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>AI Web Builder</title>
<style>
*{box-sizing:border-box}body{margin:0;font-family:Arial,sans-serif;background:#06060f;color:#eee}
main{max-width:1000px;margin:auto;padding:20px}
header{display:flex;justify-content:space-between;align-items:center;gap:12px;margin-bottom:20px;flex-wrap:wrap}
h1{color:#00ffd5;text-shadow:0 0 20px #00ffd577;margin:0}
h2{color:#00ffd5;margin-top:0}
section{background:#101020;border:1px solid #232345;border-radius:16px;padding:20px;margin-bottom:20px}
input,textarea{width:100%;padding:12px;margin:8px 0;border-radius:10px;border:1px solid #2f2f5a;background:#0b0b18;color:#fff}
button{padding:12px 18px;border:none;border-radius:10px;background:linear-gradient(90deg,#7b2cff,#00ffd5);color:#04040f;font-weight:bold;cursor:pointer}
button.ghost{background:#191932;color:#cfd8ff}
.row{display:flex;gap:10px;flex-wrap:wrap}
.badge{background:#181830;border:1px solid #2f2f5a;padding:7px 12px;border-radius:999px;font-size:13px}
iframe{width:100%;height:560px;border:1px solid #2f2f5a;border-radius:12px;background:#fff;margin-top:14px}
.user{display:flex;justify-content:space-between;align-items:center;background:#151529;border-radius:10px;padding:10px;margin:8px 0;gap:10px}
.hidden{display:none}
</style>
</head>
<body><main>
<header>
<h1>⚡ AI Web Builder</h1>
<div id="userBox" class="hidden">
<span class="badge">Usuario: <b id="username"></b></span>
<span class="badge">Créditos: <b id="credits">0</b></span>
<button class="ghost" onclick="logout()">Salir</button>
</div>
</header>

<section id="auth">
<h2>Crea tu cuenta</h2>
<p>Sin Gmail, sin teléfono y sin contraseña.</p>
<input id="registerUsername" placeholder="Elige tu nombre de usuario">
<button onclick="register()">Crear cuenta</button>
<h2>Iniciar sesión</h2>
<input id="loginUsername" placeholder="Tu nombre de usuario">
<button onclick="login()">Entrar</button>
</section>

<section id="studio" class="hidden">
<h2>Describe cualquier web o app</h2>
<textarea id="prompt" rows="6" placeholder="Ej: una tienda de ropa con carrito, contacto y diseño minimalista."></textarea>
<div class="row">
<button id="genBtn" onclick="generate()">Crear mi web — 1 crédito</button>
<button class="ghost" onclick="downloadPage()">Descargar HTML</button>
</div>
<iframe id="preview"></iframe>
</section>

<section id="admin" class="hidden">
<h2>Panel de administración</h2>
<input id="adminKey" type="password" placeholder="Clave de administrador">
<button onclick="loadUsers()">Cargar usuarios</button>
<div class="row">
<input id="adminUsername" placeholder="Usuario">
<input id="adminAmount" type="number" value="50">
<button onclick="updateCredits(1)">Agregar créditos</button>
<button class="ghost" onclick="updateCredits(-1)">Quitar créditos</button>
</div>
<div id="users"></div>
</section>
</main>

<script>
let currentHtml = "";

async function api(path, method = "GET", body = null, admin = false) {
  const headers = { "Content-Type": "application/json" };
  if (admin) headers["x-admin-key"] = adminKey.value;
  const res = await fetch(path, { method, headers, credentials: "include", body: body ? JSON.stringify(body) : null });
  return res.json();
}

async function register() {
  const data = await api("/api/register", "POST", { username: registerUsername.value.trim() });
  if (data.error) return alert(data.error);
  await loadApp();
}

async function login() {
  const data = await api("/api/login", "POST", { username: loginUsername.value.trim() });
  if (data.error) return alert(data.error);
  await loadApp();
}

async function loadApp() {
  const me = await api("/api/me");
  if (me.error) return;
  auth.classList.add("hidden");
  studio.classList.remove("hidden");
  userBox.classList.remove("hidden");
  username.textContent = me.username;
  credits.textContent = me.credits;
  admin.classList.toggle("hidden", !me.isAdmin);
}

async function generate() {
  if (!prompt.value.trim()) return alert("Describe la web que quieres crear");
  genBtn.disabled = true;
  genBtn.textContent = "Creando tu web...";
  const data = await api("/api/generate", "POST", { prompt: prompt.value.trim() });
  genBtn.disabled = false;
  genBtn.textContent = "Crear mi web — 1 crédito";
  if (data.error) return alert(data.error);
  currentHtml = data.html;
  credits.textContent = data.credits;
  preview.srcdoc = data.html;
}

function downloadPage() {
  if (!currentHtml) return alert("Primero crea una web");
  const blob = new Blob([currentHtml], { type: "text/html" });
  const a = document.createElement("a");
  a.href = URL.createObjectURL(blob);
  a.download = "mi-web.html";
  a.click();
}

async function logout() {
  await api("/api/logout", "POST");
  location.reload();
}

async function loadUsers() {
  const users = await api("/api/admin/users", "GET", null, true);
  if (users.error) return alert(users.error);
  users.innerHTML = users.map(u => \`
    <div class="user">
      <div><b>\${u.username}</b><br><small>\${u.credits} créditos</small></div>
      <button class="ghost" onclick="pickUser('\${u.username}')">Seleccionar</button>
    </div>\`).join("");
}

function pickUser(name) { adminUsername.value = name; }

async function updateCredits(sign) {
  const data = await api("/api/admin/credits", "POST", {
    username: adminUsername.value.trim(),
    amount: Number(adminAmount.value) * sign
  }, true);
  alert(data.error || \`\${data.username} ahora tiene \${data.credits} créditos\`);
  loadUsers();
}

loadApp();
</script>
</body></html>`;

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, `http://${req.headers.host}`);
  const cookies = parseCookies(req);
  const sessionToken = cookies.session_token;
  const currentUser = sessionToken ? findUserByToken(sessionToken) : null;

  if (url.pathname === "/") {
    res.writeHead(200, { "Content-Type": "text/html; charset=utf-8" });
    return res.end(HTML);
  }

  if (url.pathname === "/api/register" && req.method === "POST") {
    const body = await readBody(req);
    const username = String(body.username || "").trim();

    if (username.length < 3 || username.length > 24) {
      return sendJson(res, 400, { error: "El usuario debe tener entre 3 y 24 caracteres" });
    }
    if (!/^[a-zA-Z0-9_]+$/.test(username)) {
      return sendJson(res, 400, { error: "Solo letras, números y guion bajo" });
    }
    if (findUserByUsername(username)) {
      return sendJson(res, 409, { error: "Ese usuario ya existe" });
    }

    const user = { id: Date.now(), username, credits: INITIAL_CREDITS, isAdmin: false, createdAt: new Date().toISOString() };
    db.users.push(user);

    const token = crypto.randomBytes(32).toString("hex");
    db.devices.push({ token, userId: user.id });
    saveDb();

    res.setHeader("Set-Cookie", `session_token=${token}; HttpOnly; Path=/; SameSite=Lax; Max-Age=2592000`);
    return sendJson(res, 200, { ok: true, username, credits: user.credits });
  }

  if (url.pathname === "/api/login" && req.method === "POST") {
    const body = await readBody(req);
    const user = findUserByUsername(body.username);
    if (!user) return sendJson(res, 404, { error: "Usuario no encontrado" });

    const token = crypto.randomBytes(32).toString("hex");
    db.devices.push({ token, userId: user.id });
    saveDb();

    res.setHeader("Set-Cookie", `session_token=${token}; HttpOnly; Path=/; SameSite=Lax; Max-Age=2592000`);
    return sendJson(res, 200, { ok: true, username: user.username, credits: user.credits });
  }

  if (url.pathname === "/api/me") {
    if (!currentUser) return sendJson(res, 401, { error: "No has iniciado sesión" });
    return sendJson(res, 200, { username: currentUser.username, credits: currentUser.credits, isAdmin: currentUser.isAdmin });
  }

  if (url.pathname === "/api/logout" && req.method === "POST") {
    db.devices = db.devices.filter(d => d.token !== sessionToken);
    saveDb();
    res.setHeader("Set-Cookie", "session_token=; Path=/; Max-Age=0");
    return sendJson(res, 200, { ok: true });
  }

  if (url.pathname === "/api/generate" && req.method === "POST") {
    if (!currentUser) return sendJson(res, 401, { error: "No has iniciado sesión" });

    const body = await readBody(req);
    const prompt = String(body.prompt || "").trim();

    if (!prompt) return sendJson(res, 400, { error: "Describe la web que quieres crear" });
    if (currentUser.credits < 1) return sendJson(res, 402, { error: "No tienes créditos suficientes" });

    try {
      const result = await generateWithAI(prompt);
      currentUser.credits -= 1;
      db.generations.push({ id: Date.now(), userId: currentUser.id, username: currentUser.username, prompt, html: result.html, model: result.model, createdAt: new Date().toISOString() });
      saveDb();
      return sendJson(res, 200, { html: result.html, credits: currentUser.credits });
    } catch (error) {
      console.error(error);
      return sendJson(res, 503, { error: "La IA no está disponible ahora. No se descontó ningún crédito." });
    }
  }

  if (url.pathname === "/api/admin/users") {
    if (req.headers["x-admin-key"] !== ADMIN_KEY) {
      return sendJson(res, 403, { error: "Clave de administrador inválida" });
    }
    return sendJson(res, 200, db.users.map(u => ({ id: u.id, username: u.username, credits: u.credits, createdAt: u.createdAt })));
  }

  if (url.pathname === "/api/admin/credits" && req.method === "POST") {
    if (req.headers["x-admin-key"] !== ADMIN_KEY) {
      return sendJson(res, 403, { error: "Clave de administrador inválida" });
    }

    const body = await readBody(req);
    const user = findUserByUsername(body.username);
    const amount = Number(body.amount);

    if (!user) return sendJson(res, 404, { error: "Usuario no encontrado" });
    if (!Number.isInteger(amount)) return sendJson(res, 400, { error: "Cantidad inválida" });

    user.credits = Math.max(0, user.credits + amount);
    saveDb();
    return sendJson(res, 200, { username: user.username, credits: user.credits });
  }

  res.writeHead(404, { "Content-Type": "text/plain" });
  res.end("No encontrado");
});

server.listen(PORT, () => {
  console.log(`AI Web Builder activo en http://localhost:${PORT}`);
});
